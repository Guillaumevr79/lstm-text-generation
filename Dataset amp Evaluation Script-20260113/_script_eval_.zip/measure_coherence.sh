CUDA_VISIBLE_DEVICES=0 python ../compute_coherence.py\
    --opt_model_name facebook/opt-2.7b\
    --test_path ../wikinews/wikinews_epsilon_result.json