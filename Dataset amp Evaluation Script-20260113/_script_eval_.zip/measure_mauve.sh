CUDA_VISIBLE_DEVICES=0 python ../measure_diversity_mauve_gen_length.py\
    --test_path ../wikinews/wikinews_epsilon_result.json